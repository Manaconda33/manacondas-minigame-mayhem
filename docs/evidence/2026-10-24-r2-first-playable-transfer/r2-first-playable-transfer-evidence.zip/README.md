# R2 first-playable transfer evidence package

This package contains the report, summary, primary raw network captures, exact capture scripts, and a request-level CSV for production commit `45235d88cd65be528577db1d71b20ca5454ab979`.

## Contents

- `report.md` — methodology, thresholds, byte results, category totals, dispositions, limitations, and owner-review options.
- `summary.json` — machine-readable source pin, deployment identity, capture parameters, endpoint state, and calculated totals.
- `request-evidence.csv` — one row per captured URL per scenario with status, content encoding, browser cache flag, encoded body bytes, and transfer bytes/lower bound.
- `default-wav-circuit-alpha.json`, `opus-192k-circuit-alpha.json`, `default-wav-neon-grid.json` — raw completed primary capture records.
- Matching `.cjs` capture scripts — exact Playwright/CDP procedure.
- `SHA256SUMS` — package-file checksums, excluding itself.

## Reproduce

The capture environment used Node.js, Playwright, and Chromium 151 at `/usr/bin/chromium`. Each script opens a fresh browser context with an empty HTTP cache, leaves ordinary HTTP caching enabled, blocks service workers, and uses the deployed HTTPS origin. It stops measuring at the first visible enabled Title `PRESS START` control for the shell mark and at observed nonzero speed after ArrowUp for the first-controllable mark.

For a repeat capture in the original workspace:

1. Use a clean browser context (do not reuse a profile or service-worker cache).
2. Install/use Playwright and a Chromium binary. The scripts currently name `/usr/bin/chromium` and write into `/workspace/r2-first-playable-transfer-evidence/`.
3. Run `node wav-circuit-cold-cache.cjs`, `node opus-circuit-cold-cache.cjs`, and `node neon-wav-cold-cache.cjs`.
4. Compare generated output JSON with the schema and endpoint definitions in this package. Confirm current production SHA before interpreting results.
5. Save a DevTools Protocol Network log if per-request timing and raw cache-control response headers are required; these were not persisted in the original collector.

The test reaches Title, Hub, track selection, driver selection, race initialization, countdown, and first nonzero speed. The run uses a headless software-rendered browser. It measures real HTTPS network transfers but is not a G-05 hardware test. Chromium results must not be represented as Edge, Firefox, Safari, or mobile-device passes.

To independently inspect the CSV, sum `encoded_body_bytes` by `scenario`; the totals should match `summary.json` first-control body totals. The CSV's transfer field is exact when a request completed by the endpoint and otherwise is a lower bound. All request URLs are from the production host; no preview ZIP/artifact or local server is part of the measurement.

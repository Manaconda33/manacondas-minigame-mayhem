# R2 First-Playable Transfer Verification

**Repository:** `Manaconda33/manacondas-minigame-mayhem`  
**Measured deployment source:** `45235d88cd65be528577db1d71b20ca5454ab979`  
**Production URL:** <https://manaconda33.github.io/manacondas-minigame-mayhem/>  
**Measurement date:** 2026-10-24

## Verdict

- **Baseline / deployed source:** PASS.
- **Title shell ≤ 6,000,000 compressed bytes:** PASS in all three captures.
- **First-playable additional transfer ≤ 45,000,000 compressed bytes:** FAIL in all three captures.
- **Official measurement scope:** PASS for normal-HTTPS Chromium network capture. This is a browser/network transfer result, not a physical-device performance or G-05 result.

## Baseline verification

GitHub `main` was verified at `45235d88cd65be528577db1d71b20ca5454ab979`. Main CI run [`40095290123`](https://github.com/Manaconda33/manacondas-minigame-mayhem/actions/runs/40095290123) completed successfully. Its GitHub Pages deploy job `120881359918` completed the Pages deployment and the configured live preview/unchanged-production-byte verification. The production Pages URL served the measured application. The run's Pages and production-dist artifact sizes were not used as player-transfer evidence.

The canonical PRD, implementation status, testing guidance, and `docs/evidence/2026-10-23-release-readiness-r1/r2-evidence-checklist.md` were reviewed. PRD §2.6 sets the 6 MB pre-Title shell cap and 45 MB compressed first-playable Kart Racer target. The R2 checklist separates navigation-to-interactive-Title from the additional transfer through first controllable play. This report therefore applies 45 MB to the **post-Title first-playable interval** and shows the cumulative total separately. The result fails either a post-Title or cumulative interpretation.

## Method

Captures used the live Pages origin over HTTPS in Chromium `151.0.7922.173` with a new browser context and empty HTTP cache; normal browser HTTP caching remained enabled. Service workers were blocked so a prior service-worker response could not masquerade as a cold network transfer. The runtime was headless Chromium using SwiftShader; that rendering choice does not affect the HTTPS request-byte measurements and is not physical-device performance evidence.

The three paths were exercised:

1. Ordinary production URL, WAV default, Circuit Alpha selected.
2. `?musicFormat=opus-192k`, Circuit Alpha selected.
3. Ordinary production URL, WAV default, Neon Grid selected.

The first endpoint is the visible, enabled Title `PRESS START` control. The second endpoint is after entering Hub, selecting track and driver, starting the race, waiting for the countdown, pressing ArrowUp, and observing nonzero speed. All three runs reached nonzero speed (3 km/h) within 0.12–0.13 displayed race seconds after control input.

Chrome DevTools Protocol Network events recorded requested URLs, response status, `Content-Encoding`, cache flags, encoded body bytes, transfer bytes, and errors. The request-level CSV has the fields preserved by the collector. It does not contain per-request timestamps or raw response cache-control headers: the collector did not persist those fields, so they are not inferred. Capture endpoint timestamps and the complete URL/status/byte records are preserved in each JSON file. `encodedDataLength` event totals are the compressed response-body bytes actually received. The transfer total also includes HTTP overhead for requests completed before the endpoint; for in-flight requests its transfer value is a lower bound. Title transfer is explicitly reported as a lower bound for that reason. The post-Title difference is computed from encoded body bytes, which are directly event-summed through the control endpoint.

All primary-capture requests completed with HTTP 200; no failed network requests were recorded. Repeat favicon and selected-kart requests served from the browser cache reported zero transferred body bytes. No `/previews/` path was requested. No request was reported as a retry. Browser `blob:` resources have no network body transfer. `Content-Encoding: identity` describes the HTTP response encoding; PNG, GLB, Ogg, and other already-compressed file formats remain compressed assets.

## Results

Byte limits are decimal MB: 6 MB = 6,000,000 bytes; 45 MB = 45,000,000 bytes.

| Scenario | Shell body through Title | Title transfer (lower bound) | First-control cumulative encoded body | First-control transfer | Additional body after Title | 6 MB shell | 45 MB additional |
|---|---:|---:|---:|---:|---:|---|---|
| WAV default · Circuit Alpha | 366,537 B (0.367 MB) | 369,369 B | 106,060,509 B (106.061 MB) | 106,103,730 B | 105,693,972 B (105.694 MB) | PASS | **FAIL +60,693,972 B** |
| Opus 192k opt-in · Circuit Alpha | 723,921 B (0.724 MB) | 728,492 B | 52,786,491 B (52.786 MB) | 52,829,837 B | 52,062,570 B (52.063 MB) | PASS | **FAIL +7,062,570 B** |
| WAV default · Neon Grid | 848,641 B (0.849 MB) | 853,097 B | 109,327,626 B (109.328 MB) | 109,371,105 B | 108,478,985 B (108.479 MB) | PASS | **FAIL +63,478,985 B** |

The 45 MB first-playable target is exceeded even on the Opus path. Because its 52,062,570-byte post-Title body is greater than 45 MB, the result remains a failure whether the requirement counts the post-Title increment or the whole navigation-to-control cumulative body.

## Encoded-body category totals through first control

| Category | WAV Circuit Alpha | Opus Circuit Alpha | WAV Neon Grid |
|---|---:|---:|---:|
| Music WAV | 56,870,965 B | 0 B | 56,870,749 B |
| Music Opus | 0 B | 7,400,077 B | 0 B |
| Character assets | 29,236,248 B | 25,433,172 B | 27,735,871 B |
| Track assets | 11,456,553 B | 11,456,382 B | 16,224,245 B |
| SFX | 5,117,127 B | 5,117,226 B | 5,117,109 B |
| Route Night UI / branding | 1,820,689 B | 1,820,689 B | 1,820,707 B |
| JavaScript | 1,540,396 B | 1,540,414 B | 1,540,414 B |
| CSS | 18,174 B | 18,174 B | 18,174 B |
| Other / favicon | 357 B | 357 B | 357 B |

Totals are derived from request URL classes in the raw CSV; a category total is encoded body bytes, not decoded file size. The first-control requests included 236 (WAV Circuit Alpha), 241 (Opus Circuit Alpha), and 241 (WAV Neon Grid) request records, respectively.

### Largest contributors and comparison

- In the WAV Circuit Alpha path, the four music tracks requested before first control total **56,870,965 B**. This one category exceeds the entire 45 MB budget by 11.87 MB.
- In the Opus Circuit Alpha path, four Opus music assets total **7,400,077 B**. The four WAV tracks were not requested, and there was no WAV fallback traffic. The music transfer saving is **49,470,888 B** (about 87.0%) across those four tracks.
- The total body difference between the two Circuit Alpha captures is 53,274,018 B (about 50.2%). It is not attributed entirely to audio: separately launched sessions selected different AI/character resources, and character asset totals differed by 3,803,076 B.
- Character assets remain the largest Opus-path category at **25,433,172 B**, mostly driver sprites (22,395,455 B in that run). This is a substantial remaining first-playable cost; the capture alone does not establish which of those assets can safely be deferred or reduced.
- Circuit Alpha track assets total **11,456,382 B** on the Opus run. Neon Grid track assets total **16,224,245 B**, a net **4,767,863 B** increase in these independently selected sessions. Neon Grid loads its concrete maps and billboard/signage assets while not sharing Circuit Alpha's exact track asset set. The net difference is the observed route-category difference, not a byte-for-byte causal estimate of a single asset group.
- SFX total about **5.12 MB** before first control. 96 SFX requests were observed. The captured transfer establishes when they were downloaded, but does not by itself prove which sounds are essential to race start or safe to defer.
- The Title shell itself is below 0.85 MB in each run, far under the 6 MB limit.

The Opus query remains an opt-in selector; the ordinary URL continues to use WAV. This assignment does not authorize changing that default.

## Dispositions

| Requirement / check | Disposition | Evidence or limitation |
|---|---|---|
| Live source matches approved measurement SHA | PASS | GitHub main SHA and successful CI/Pages run verified above. |
| Production HTTPS request capture | PASS | Three complete Chromium captures from production Pages, each reaching first nonzero speed. |
| 6 MB pre-Title shell | PASS | 366,537–848,641 encoded body bytes. |
| 45 MB first-playable transfer, default WAV Circuit Alpha | FAIL | Additional interval 105,693,972 B. |
| 45 MB first-playable transfer, Opus Circuit Alpha | FAIL | Additional interval 52,062,570 B. |
| 45 MB first-playable transfer, default WAV Neon Grid | FAIL | Additional interval 108,478,985 B. |
| Request failures / retries | PASS for observed runs | All primary response statuses were 200; no failed requests or retries recorded. |
| Other browser engines | UNMEASURED | Only Chromium was available for this capture. No Edge, Firefox, or Safari result is claimed. |
| Physical device / G-05 performance | UNMEASURED | Software-rendered headless browser is not representative-device performance evidence. |
| Per-request wall-clock timing and response cache-control headers | UNMEASURED | Not retained by the capture collector; do not infer. |

## Smallest corrective options for owner review

1. **Assess whether to adopt the already implemented Opus path as the default in a separately approved change.** The measured saving on the four pre-control music tracks is 49,470,888 B with no WAV requests or fallback traffic in the successful Opus run. This would not by itself satisfy 45 MB: the Opus run still exceeds the post-Title budget by 7,062,570 B. No default change is made here.
2. **Then investigate one narrow, evidence-led reduction among first-playable character assets or other large asset groups.** The largest observed category is the driver asset set. Any deferral or compression would require checking first-playable roster usability and in-race availability; this report does not estimate a safe saving.
3. **Measure route-specific asset improvements separately.** Neon Grid's observed track category is 4,767,863 B above Circuit Alpha's, but that is not the cause of the default WAV overrun and is not a controlled same-session diff.

No runtime, asset, PRD, workflow, CI, default, deployment, or production change was made for this report.

## Reproduction

See `README.md` for environment requirements and exact steps. The three `.cjs` scripts preserve the actual browser interaction and collection logic used. Run each in a clean Chromium context against the production HTTPS URL and retain its JSON output. The scripts require Playwright and a Chromium executable at `/usr/bin/chromium`; edit only the local output path if using another environment. Do not disable the cache for the primary cold-browser run; cache-disabled sessions are included only as supplemental conservative comparisons in the original workspace, not in the primary request totals.

# R2.12 G-05 original raw-capture preservation package

This archive contains two unmodified original JSON uploads from the product owner's 2026-10-25 desktop playtest, plus SHA256SUMS and these independent verification notes.

- The two exports originate from one completed Neon Grid race, not two distinct race runs. Both contain an identical 9,630-frame trace.
- Source commit: `12e996ff5b77b3cbfdd5973aabae75f7ca89fa70`.
- Windows / Chrome 156 / AMD Radeon via ANGLE Direct3D 11; Medium; 1920 x 911 actual buffer; eight racers.
- Summary: medianFPS 59.8802395210207, p95FrameMs 16.79999999998836, longestOver50msRun 2, maxDrawCalls 486, maxTriangles 348923, maxFrameMs 1199, raceCompleted true, truncated false.
- Maximum 1199 ms frame is `samples[9527]` (zero-based), frame 9528 (one-based), in **both** JSON files.
- Export-specific differences include timestamp and `metadata.jsHeapBytes` (122,791,795 and 103,536,966); neither value is a standalone GPU-memory or race allocation result.
- `initializationScene` captured first-render counts 188 draw calls, 222311 triangles, with 3 AI kart assets pending. `assetSettledScene` shows 204 draw calls, 287443 triangles with seven of seven AI assets loaded.
- This is source data supporting v1 `OWNER ACCEPTED BY EXCEPTION`, *not* an unconditional technical PASS or formal v1 release acceptance.
- This package is outside the GitHub repository until ingested; no commit or PR change is implied by the archive's creation.

Verify original files via: `sha256sum -c SHA256SUMS` after extracting.
